<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReadlistArticle extends Model
{
    //
}
