<div class="item" data-value="Algeria"><i class="dz flag"></i>Algeria</div>
<div class="item" data-value="Angola"><i class="ao flag"></i>Angola</div>
<div class="item" data-value="Ascension"><i class="sh flag"></i>Ascension</div>
<div class="item" data-value="Benin"><i class="bj flag"></i>Benin</div>
<div class="item" data-value="Botswana"><i class="bw flag"></i>Botswana</div>
<div class="item" data-value="Burkina Faso"><i class="bf flag"></i>Burkina Faso</div>
<div class="item" data-value="Burundi"><i class="bi flag"></i>Burundi</div>
<div class="item" data-value="Cameroon"><i class="cm flag"></i>Cameroon</div>
<div class="item" data-value="Cape Verde Islands"><i class="cv flag"></i>Cape Verde Islands</div>
<div class="item" data-value="Central African Republic"><i class="cf flag"></i>Central African Republic</div>
<div class="item" data-value="Chad Republic"><i class="td flag"></i>Chad Republic</div>
<div class="item" data-value="Comoros"><i class="km flag"></i>Comoros</div>
<div class="item" data-value="Congo"><i class="cg flag"></i>Congo</div>
<div class="item" data-value="Dem. Republic of the Congo"><i class="cd flag"></i>Dem. Republic of the Congo</div>
<div class="item" data-value="Djibouti"><i class="dj flag"></i>Djibouti</div>
<div class="item" data-value="Egypt"><i class="eg flag"></i>Egypt</div>
<div class="item" data-value="Equatorial Guinea"><i class="gq flag"></i>Equatorial Guinea</div>
<div class="item" data-value="Eritrea"><i class="er flag"></i>Eritrea</div>
<div class="item" data-value="eSwatini"><i class="sz flag"></i>eSwatini</div>
<div class="item" data-value="Ethiopia"><i class="et flag"></i>Ethiopia</div>
<div class="item" data-value="Gabon Republic"><i class="ga flag"></i>Gabon Republic</div>
<div class="item" data-value="Gambia"><i class="gm flag"></i>Gambia</div>
<div class="item" data-value="Ghana"><i class="gh flag"></i>Ghana</div>
<div class="item" data-value="Guinea"><i class="gn flag"></i>Guinea</div>
<div class="item" data-value="Guinea-Bissau"><i class="gw flag"></i>Guinea-Bissau</div>
<div class="item" data-value="Ivory Coast"><i class="ci flag"></i>Ivory Coast</div>
<div class="item" data-value="Kenya"><i class="ke flag"></i>Kenya</div>
<div class="item" data-value="Lesotho"><i class="ls flag"></i>Lesotho</div>
<div class="item" data-value="Liberia"><i class="lr flag"></i>Liberia</div>
<div class="item" data-value="Libya"><i class="ly flag"></i>Libya</div>
<div class="item" data-value="Madagascar"><i class="mg flag"></i>Madagascar</div>
<div class="item" data-value="Malawi"><i class="mw flag"></i>Malawi</div>
<div class="item" data-value="Mali Republic"><i class="ml flag"></i>Mali Republic</div>
<div class="item" data-value="Mauritania"><i class="mr flag"></i>Mauritania</div>
<div class="item" data-value="Mauritius"><i class="mu flag"></i>Mauritius</div>
<div class="item" data-value="Mayotte Island"><i class="yt flag"></i>Mayotte Island</div>
<div class="item" data-value="Morocco"><i class="ma flag"></i>Morocco</div>
<div class="item" data-value="Mozambique"><i class="mz flag"></i>Mozambique</div>
<div class="item" data-value="Namibia"><i class="na flag"></i>Namibia</div>
<div class="item" data-value="Niger Republic"><i class="ne flag"></i>Niger Republic</div>
<div class="item" data-value="Nigeria"><i class="ng flag"></i>Nigeria</div>
<div class="item" data-value="Principe"><i class="st flag"></i>Principe</div>
<div class="item" data-value="Reunion Island"><i class="re flag"></i>Reunion Island</div>
<div class="item" data-value="Rwanda"><i class="rw flag"></i>Rwanda</div>
<div class="item" data-value="Sao Tome"><i class="st flag"></i>Sao Tome</div>
<div class="item" data-value="Senegal Republic"><i class="sn flag"></i>Senegal Republic</div>
<div class="item" data-value="Seychelles"><i class="sc flag"></i>Seychelles</div>
<div class="item" data-value="Sierra Leone"><i class="sl flag"></i>Sierra Leone</div>
<div class="item" data-value="Somalia Republic"><i class="so flag"></i>Somalia Republic</div>
<div class="item" data-value="South Africa"><i class="za flag"></i>South Africa</div>
<div class="item" data-value="South Sudan"><i class="ss flag"></i>South Sudan</div>
<div class="item" data-value="St. Helena"><i class="sh flag"></i>St. Helena</div>
<div class="item" data-value="Sudan"><i class="sd flag"></i>Sudan</div>
<div class="item" data-value="Swaziland"><i class="sz flag"></i>Swaziland</div>
<div class="item" data-value="Tanzania"><i class="tz flag"></i>Tanzania</div>
<div class="item" data-value="Togo"><i class="tg flag"></i>Togo</div>
<div class="item" data-value="Tunisia"><i class="tn flag"></i>Tunisia</div>
<div class="item" data-value="Uganda"><i class="ug flag"></i>Uganda</div>
<div class="item" data-value="Zaire"><i class="cd flag"></i>Zaire</div>
<div class="item" data-value="Zambia"><i class="zm flag"></i>Zambia</div>
<div class="item" data-value="Zanzibar"><i class="tz flag"></i>Zanzibar</div>
<div class="item" data-value="Zimbabwe"><i class="zw flag"></i>Zimbabwe</div><?php /**PATH D:\xampp\htdocs\IABC\iabc_africa\resources\views/partials/_countries.blade.php ENDPATH**/ ?>