<div class="ui sidebar inverted large vertical menu">
    <span class="item d-block sidebar_off">
        <div class="ui inverted list">
            <div class="item">
                <div class="ui very padded header">
                    <i class="ui small times icon"></i>
                    IABC Africa
                </div>
            </div>
        </div>
    </span>
    <?php if(auth()->guard()->check()): ?>
    <?php if(Auth::user()->role == 'superadmin' || Auth::user()->role == 'admin'): ?>
    <span class="item d-block drop_item">
        <div class="ui accordion">
            <div class="title dropdown_item">
                <div class="ui inverted list">
                    <div class="item">
                        <div class="content_item mb-1 centered">
                            <div class="ui fluid labeled button" tabindex="0">
                                <div class="ui fluid button">
                                    <div class="ui inverted orange header">ADMIN PANEL</div>
                                </div>
                                <div class="ui basic icon label">
                                    <i class="large orange angle left icon"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content">
                <div class="ui inverted list p-0">
                    <div class="left aligned item">
                        <div class="list p-0">
                            <?php if(Auth::user()->role == 'superadmin'): ?>
                            <div class="item">
                                <a class="ui fluid inverted large orange button text-left">Dashboard</a>
                            </div>
                            <div class="item">
                                <a href="<?php echo e(route('users.index')); ?>" class="ui fluid inverted large orange button text-left">Users</a>
                            </div>
                            <div class="item">
                                <a href="<?php echo e(route('sidebars.index')); ?>" class="ui fluid inverted large orange button text-left">Sidebar</a>
                            </div>
                            <?php endif; ?>
                            <?php if(Auth::user()->role == 'admin' OR Auth::user()->role == 'superadmin'): ?>
                            <div class="ui item">
                                <a href="<?php echo e(route('articles.index')); ?>" class="ui fluid inverted large orange button text-left">Articles</a>
                            </div>
                            <div class="ui item">
                                <a href="<?php echo e(route('topics.index')); ?>" class="ui fluid inverted large orange button text-left">Topics & Subtopics</a>
                            </div>
                            <?php endif; ?>
                            <?php if(Auth::user()->role == 'superadmin'): ?>
                            <div class="ui item">
                                <a class="ui fluid inverted large orange button text-left">Business Profile</a>
                            </div>
                            <div class="ui item">
                                <a class="ui fluid inverted large orange button text-left">Subscriptions</a>
                            </div>
                            <?php endif; ?>
                            <!-- <div class="item">
                                <div class="ui fluid large labeled button" tabindex="0">
                                    <a class="ui fluid orange button">
                                        <i class="heart icon"></i> Like
                                    </a>
                                    <span class="ui basic orange left pointing label">
                                        1,048
                                    </span>
                                </div>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </span>
    <?php endif; ?>
    <?php endif; ?>
    <span class="item d-block drop_item">
        <div class="ui inverted accordion">
            <div class="title p-0 dropdown_item">
                <div class="ui inverted list">
                    <div class="item">
                        <div class="ui right floated content">
                            <i class="angle left icon"></i>
                        </div>
                        <div class="content_item mb-1">
                            TOPICS
                        </div>
                    </div>
                </div>
            </div>
            <div class="content">
                <div class="ui inverted relaxed link list pt-0">
                    <div class="item">
                        <div class="list pt-0">
                            <div class="item">
                                <div class="ui inverted relaxed animated list">
                                <?php $__currentLoopData = $activetopics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activetopic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('topic.articles', slug($activetopic->name))); ?>" class="item"><?php echo e($activetopic->name); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </span>
    <?php $__currentLoopData = $activesidebars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activesidebar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('home') . '/' . $activesidebar->link); ?>" class="item">
        <div class="ui inverted list">
            <div class="item uppercase">
                <?php echo e($activesidebar->name); ?>

            </div>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    <!-- <a class="item">
        <div class="ui inverted list">
            <div class="item">
                WOMEN ENTREPRENEUR
            </div>
        </div>
    </a>
    <a class="item">
        <div class="ui inverted list">
            <div class="item">
                VIDEOS
            </div>
        </div>
    </a>
    <a class="item">
        <div class="ui inverted list">
            <div class="item">
                IABC AFRICA 1000
            </div>
        </div>
    </a>
    <a class="item">
        <div class="ui inverted list">
            <div class="item">
                AGRIBUSINESS
            </div>
        </div>
    </a>
    <a class="item">
        <div class="ui inverted list">
            <div class="item">
                OPPORTUNITIES
            </div>
        </div>
    </a>
    <a class="item">
        <div class="ui inverted list">
            <div class="item">
                CONTACT US
            </div>
        </div>
    </a> -->
</div>

<?php /**PATH D:\xampp\htdocs\IABC\iabc_africa\resources\views/partials/_sidebar.blade.php ENDPATH**/ ?>