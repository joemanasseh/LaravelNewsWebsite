<?php $__env->startSection('content'); ?>

    <div class="ui container">
        <div class="ui header">Post View</div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IABC\iabc_africa\resources\views/post_view.blade.php ENDPATH**/ ?>