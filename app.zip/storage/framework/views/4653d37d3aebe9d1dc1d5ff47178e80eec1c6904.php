

<?php $__env->startSection('content'); ?>

    <!-- <section>
        <div class="ui grid">
            <div class="sixteen wide computer only center aligned column">
                <div class="ui gigantic header">
                    COMING SOON
                </div>
                <div class="ui large header">
                    This Feature is Under Construction and Will be Available Soon
                </div>
                <img src="<?php echo e(asset('img/ui/loading.gif')); ?>" alt="">
            </div>
            <div class="fourteen wide centered mobile only center aligned column">
                <div class="ui bigger header">
                    COMING SOON
                </div>
                <div class="ui header">
                    This Feature is Under Construction and Will be Available Soon
                </div>
                <img src="<?php echo e(asset('img/ui/loading.gif')); ?>" alt="">
            </div>
        </div>
    </section> -->

<?php $__env->stopSection(); ?>


<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iabcafri/iabc/resources/views/errors/cs.blade.php ENDPATH**/ ?>