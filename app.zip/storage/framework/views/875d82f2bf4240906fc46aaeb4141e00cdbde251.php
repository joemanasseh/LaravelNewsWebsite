
<?php $__currentLoopData = $user->readlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $red): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($red->articles->title); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<?php $__currentLoopData = $readlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $real): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php echo e($real->articles); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>

<?php $__currentLoopData = $readlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $read): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php echo e($read->articles_id); ?>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


<?php echo e($readlist); ?>



<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>


<?php echo e($articulate); ?><?php /**PATH D:\xampp\htdocs\IABC\iabc_africa\resources\views/readlist_test.blade.php ENDPATH**/ ?>