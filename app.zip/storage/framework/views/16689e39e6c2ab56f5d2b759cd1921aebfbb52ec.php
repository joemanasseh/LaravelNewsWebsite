<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->yieldContent('article_meta'); ?>
    <script src="<?php echo e(asset('js/jquery-3.3.1.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/semantic.min.css')); ?>">
    <?php echo $__env->yieldContent('extra_links'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Raleway:500&display=swap" rel="stylesheet">
    <link rel="icon" href="<?php echo e(asset('img/logo/favicon.png')); ?>" type="image/png"/>
    <link rel="shortcut icon" href="<?php echo e(asset('img/logo/favicon.png')); ?>" type="image/png"/>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>


<?php /**PATH D:\xampp\htdocs\IABC\iabc_africa\resources\views/partials/_head.blade.php ENDPATH**/ ?>