<?php $__env->startSection('extra_links'); ?>
    <script type="text/javascript" src="https://platform-api.sharethis.com/js/sharethis.js#property=5d92bc772303400012f9304f&product=inline-share-buttons" async="async"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'IABC Africa - ' . titleCase($article->title)); ?>

<?php $__env->startSection('article_meta'); ?>
    <meta property="og:title" content="<?php echo e(titleCase($article->title)); ?>">
    <meta property="og:description" content="<?php echo e($article->description); ?>">
    <meta property="og:image" content="<?php echo e(asset('img/articles/' . sprintf('%06d', $article->id) . '-' . slug($article->title) . '/featured/' . $article->image)); ?>">
    <meta property="og:url" content="<?php echo e(route('articles.read', slug($article->title))); ?>">
    <meta name="twitter:card" content="summary_large_image">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="ui container mt-20">
        <div class="ui grid">
            <!-- <div class="ui ten wide centered blue column"></div> -->

            <div class="fourteen wide computer sixteen wide mobile centered column post_show_main">
                <a href="<?php echo e(route('topic.articles', slug($article->topic->name))); ?>" class="ui blue text text-bold uppercase"><?php echo e($article->topic->name); ?></a>
                <div class="ui large header mt-0">
                    <div class="ui large header mt-0 article_title" data-title="<?php echo e($article->id); ?>">
                        <?php echo e(titleCase($article->title)); ?>

                    </div>
                    <div class="sub header text-italic"><?php echo e($article->description); ?></div>
                </div>
                <div class="ui divider"></div>
                <div class="ui grid">
                <div class="five wide computer sixteen wide mobile column">
                    <div class="sharethis-inline-share-buttons"></div>
                </div>
                    <!-- <div class="ui one wide computer three wide mobile middle aligned column">
                        <div class="ui center aligned header">
                            00
                            <div class="sub header">Shares</div>
                        </div>
                    </div>
                    <div class="one wide computer three wide mobile center aligned column" data-tooltip="Share on Facebook">
                        <i class="ui large blue facebook f circular link icon"></i>
                    </div>
                    <div class="one wide computer three wide mobile center aligned column" data-tooltip="Tweet this Article">
                        <i class="ui large blue twitter circular link icon"></i>
                    </div>
                    <div class="one wide computer three wide mobile center aligned column" data-tooltip="Share on LinkedIn">
                        <i class="ui large blue linkedin in circular link icon"></i>
                    </div>
                    <div class="one wide computer three wide mobile center aligned column" data-tooltip="Share on Linkify">
                        <i class="ui large linkify circular link icon"></i>
                    </div> -->
                    <div class="three wide computer eight wide mobile center aligned column">
                        <div class="ui fluid basic large orange button border border-orange" id="readlist">Save to Readlist</div>
                        <form id="readlist" action="<?php echo e(route('readlists.store')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <input hidden type="text" name="article_id" id="" value="<?php echo e($article->id); ?>">
                        </form>
                    </div>
                    <div class="three wide computer eight wide mobile right floated middle aligned column">
                        
                        <a <?php if(!empty($nextarticle)): ?> href="<?php echo e(route('articles.read', slug($nextarticle->title))); ?>" <?php endif; ?> class="<?php if(empty($nextarticle)): ?> disabled <?php endif; ?> ui right floated blue header">NEXT ARTICLE</a>
                        
                    </div>
                </div>
                <div class="ui divider"></div>
                <div class="ui stackable grid">
                    <div class="twelve wide column">
                        <img src="<?php echo e(asset('img/articles/' . sprintf('%06d', $article->id) . '-' . slug($article->title) . '/featured/' . $article->image)); ?>" alt="" class="ui fluid image">
                        <div class="ui text-italic right floated large sub header my-0 d-block text-ucfirst"><?php echo e(!empty($article->image_credit) ? 'Image Credit: '.$article->image_credit : ''); ?></div>
                        <div class="ui large header">
                            <img src="<?php echo e(asset('img/users/' . $article->user->photo)); ?>" alt="" class="ui circular image">
                            <div class="content">
                                <a href="<?php echo e(route('profiles.author', slug($article->user->username))); ?>">
                                    <?php echo e($article->user->lastname.' '.$article->user->firstname); ?>

                                </a>
                                <div class="ui sub header text-bold"><?php echo e($article->user->author); ?></div>
                                <div class="sub header text-italic"><?php echo e($article->user->job_desc); ?></div>
                                <!-- <div class="ui icons mt-10">
                                    <i class="ui small blue circular twitter icon"></i>
                                    <i class="ui small blue circular linkedin in icon"></i>
                                    <i class="ui small blue circular home icon"></i>
                                    <i class="ui small circular swatchbook icon"></i>
                                </div> -->
                            </div>
                        </div>
                        <div class="ui very relaxed horizontal list">
                            <div class="item">
                                <div class="ui tiny header">
                                    <i class="calendar alternate icon"></i>
                                    <?php echo e(date('jS F, o', strtotime($article->created_at))); ?>

                                </div>
                            </div>
                            <div class="item">
                                <div class="ui tiny header">
                                    <i class="book reader icon"></i>
                                    <?php echo e(round(str_word_count($article->body) / 250)); ?> mins read
                                </div>
                            </div>
                        </div>
                        <div class="tiny sub header mt-10">
                            Opinions expressed by <em>IABC</em> contributors are their own. 
                        </div>
                        <div class="ui header post-body article text-justify">
                            <?php echo $article->body; ?>

                        </div>
                    </div>
                    <div class="four wide column">
                        <!-- <img src="<?php echo e(asset('img/bg/business3.jpg')); ?>" alt="" class="ui fluid image"> -->
                        <div class="ui large dividing header">RELATED ARTICLES</div>
                        <div class="ui divided list">
                        <?php if(count($topicarticles) != 0): ?>
                        <?php $__currentLoopData = $topicarticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topicarticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ui item">
                                <div class="content mt-10">
                                    <a href="<?php echo e(route('topic.articles', slug($topicarticle->topic->name))); ?>" class="ui tiny blue text"><?php echo e(strtoupper($topicarticle->topic->name)); ?></a>
                                    <a href="<?php echo e(route('articles.read', slug($topicarticle->title))); ?>">
                                        <div class="ui header mt-0"><?php echo e($topicarticle->title); ?></div>
                                    </a>
                                    <div class="ui text mt-10">
                                        <?php echo e($topicarticle->description); ?> 
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="ui basic horizontal center aligned segments">
                                        <div class="ui vertically fitted segment">
                                            <i class="user icon"></i>
                                            <a href="<?php echo e(route('profiles.author', slug($topicarticle->user->username))); ?>">
                                                <?php echo e($topicarticle->user->lastname.' '.$topicarticle->user->firstname[0].'.'); ?>

                                            </a>
                                        </div>
                                        <div class="ui vertically fitted segment">
                                            <i class="book reader icon"></i>
                                            <?php echo e(round(str_word_count($topicarticle->body) / 250)); ?> mins
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--  -->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="ui red centered header">No Related Articles</div>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
                <!--  -->

                <!--  -->
                
            </div>
        </div>
        <!--  -->

        <!--  -->
        <div class="ui fluid bordered image my-50">
            <img src="<?php echo e(asset('img/bg/ad_placeholder.png')); ?>" alt="">
        </div>
        <!--  -->

    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_script'); ?>

var article_title = $('.article_title').attr('data-title');

$('div[data-tooltip="Share on Facebook"]').click(function(e) {
    e.preventDefault();
    alert(article_title);
    FB.ui({
        method: 'share',
        href: 'https://iabcafrica.com/article/' + article_title,
    }, function(response){});
});


$('div#readlist').click(function(e) {
    e.preventDefault();
    $(this).addClass('loading');
    $('form#readlist').submit();
});

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IABC\iabc_africa\resources\views/articles/read.blade.php ENDPATH**/ ?>