

<?php $__env->startSection('content'); ?>

    <section class="ui container">
        
        <div class="ui grid">
            <div class="ui eight wide computer sixteen wide mobile centered column">
                <div class="ui raised segments">
                    <div class="ui center aligned raised segment">
                        <div class="ui large header mb-0">Reset Password</div>
                    </div>
                    <div class="ui raised segment">
                        <div class="ui very padded grid">
                            <div class="ui column">
                                <?php if(session('status')): ?>
                                <div class="ui success message">
                                    <div class="header">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                </div>
                                <?php endif; ?>

                                <form class="ui error form" method="POST" action="<?php echo e(route('password.email')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php if(count($errors) > 0): ?>
                                    <div class="ui error message">
                                        <div class="header">Please check your input</div>
                                        <ul class="list">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input_error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($input_error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <?php endif; ?>

                                    <div class="field <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <label>Email Address</label>
                                        <input id="email" type="email" name="email" placeholder="Enter email address" value="<?php echo e(old('email')); ?>" autocomplete="email" required autofocus>
                                    </div>

                                    <button class="ui orange large fluid button" type="submit">Send Password Reset Link</button>
                                </form>
                                
                            </div>
                            
                        </div>
                        <!--  -->
                    </div>
                </div>
                
            </div>
        </div>
        <!--  -->
        <!--  -->


    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iabcafri/iabc/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>