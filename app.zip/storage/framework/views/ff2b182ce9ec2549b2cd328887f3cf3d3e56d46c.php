<div class="ui grid">
    <!-- <div class="ui red row pb-0"> -->
        <div class="ui sixteen wide column">
            <div class="ui inverted basic segment">
                <div class="ui stackable grid">
                    <div class="ui three wide column">
                        <div class="ui inverted tiny secondary menu">
                            <div class="item">
                                <div class="ui large inverted header">
                                    <span class="sidebar_on" data-tooltip="Show Sidebar" data-position="bottom left" data-variation="basic">
                                        <i class="bars link icon"></i>
                                    </span>
                                    <a href="/" class="content text-white">
                                        IABC Africa
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--  -->
                    <div class="ui ten wide column">
                        <div class="ui inverted compact stackable menu">
                            <a href="/" class="active item home">HOME</a>
                            <div class="ui nav_dropdown dropdown item nav_border_l">
                                ABOUT US
                                <i class="dropdown icon"></i>
                                <div class="ui menu">
                                    <a href="<?php echo e(route('about')); ?>" class="item">About IABC</a>
                                    <a href="<?php echo e(route('profiles.author', slug('gospel'))); ?>" class="item">Meet the Founder</a>
                                    <a class="item">Testimonials</a>
                                </div>
                            </div>
                            <div class="ui nav_dropdown dropdown item nav_border_l">
                                AFRICA'S BUSINESS TODAY
                                <i class="dropdown icon"></i>
                                <div class="menu">
                                    <a class="item">Africa Business News</a>
                                    <a class="item">Africa’s Enterpreneurs’ Profile</a>
                                    <a class="item">Africa’s SME today</a>
                                </div>
                            </div>
                            <a class="item nav_border_l">BUSINESS PROFILE</a>
                            <a class="item nav_border_l">FORUM</a>
                            <a href="<?php echo e(route('contact')); ?>" class="item nav_border_l cu">CONTACT US</a>
                        </div>
                    </div>
                    <!--  -->
                    <div class="ui three wide right floated column">
                        <div class="ui inverted right floated compact menu social_icon">
                            <div style="display:none;" class="search_input item">
                                <div class="ui icon input">
                                    <input type="text" placeholder="Search...">
                                    <i class="search icon"></i>
                                </div>
                            </div>
                            <a class="ui search icon item" data-tooltip="Search This Website" data-position="bottom left" data-variation="basic">
                                <i class="search icon"></i>
                            </a>
                            <?php if(auth()->guard()->guest()): ?>
                            <a class="ui icon item account" data-tooltip="Login" data-position="bottom center" data-variation="basic">
                                <i class="user icon"></i>
                            </a>
                            <div id="login_modal" class="ui tiny center aligned modal account">
                                
                                <i class="close icon"></i>
                                <div class="header">
                                    <div class="ui huge centered header">
                                        IABC Africa <br>
                                    </div>
                                    <div class="ui tiny centered header mt-0">
                                        Members get exclusive deals, event invites and more.
                                    </div>
                                </div>
                                <div class="content">
                                    <div class="ui very padded stackable grid">
                                        <div class="ui two column row">
                                            <div class="ui column">
                                                <div class="ui labeled icon fluid blue button login px-0">
                                                    <i class="facebook f icon"></i>
                                                    <span>Login with Facebook</span>
                                                </div>
                                            </div>
                                            <div class="ui column">
                                                <div class="ui labeled icon fluid red button login">
                                                    <i class="google icon"></i>
                                                    <span>Login with Google</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                    <div class="ui very padded grid">
                                        <div class="ui column">
                                            <form class="ui error form" method="POST" action="<?php echo e(route('login')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php if(count($errors) > 0): ?>
                                                <div class="ui error message">
                                                    <div class="header">Please check your input</div>
                                                    <ul class="list">
                                                        <li><?php echo e($errors->first('email')); ?></li>
                                                    </ul>
                                                </div>
                                                <?php endif; ?>

                                                <div class="field <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                                    <label>Email</label>
                                                    <input id="email" type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" autocomplete="email" required>
                                                </div>

                                                <div class="field <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> ">
                                                    <label>Password</label>
                                                    <input id="password" type="password" name="password" placeholder="Password" required>
                                                </div>

                                                <div class="field">
                                                    <div class="ui checkbox">
                                                        <input type="checkbox" tabindex="0" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                                        <label for="remember">Remember Me</label>
                                                    </div>
                                                    <a href="<?php echo e(route('password.request')); ?>" class="ui right floated primary tiny header">Forgot Password?</a>
                                                </div>
                                                
                                                <button class="ui orange large fluid button" type="submit">Login</button>
                                            </form>
                                        </div>
                                        
                                    </div>
                                    
                                    <!--  -->
                                    <div class="ui very padded grid">
                                        <div class="ui center aligned column">
                                            <div class="ui text">Don't have an account? &nbsp; <a href="<?php echo e(route('register')); ?>" class="ui tiny primary header"> Sign Up</a> </div>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                            <?php else: ?>
                            <div class="ui inverted icon top left pointing nav_dropdown dropdown link item" data-tooltip="User Account"  data-position="bottom center" data-variation="basic">
                                <i class="user icon"></i>
                                <div class="menu">
                                    <div class="ui fluid message">
                                        <div class="header">
                                            Currently Logged In As:
                                        </div>
                                        <div class="ui large header mt-10">
                                            <img src="<?php if(!empty(Auth::user()->photo)): ?> <?php echo e(asset('img/users/'. Auth::user()->photo)); ?> <?php else: ?> <?php echo e(asset('img/users/head.jpg')); ?> <?php endif; ?>"  alt="" class="ui avatar image border border-orange">
                                            <div class="content pl-0">
                                                <div class="ui small header">
                                                    <?php echo e(Auth::user()->lastname.' '.Auth::user()->firstname[0].'. '); ?>

                                                    <?php if(!empty(Auth::user()->othername)): ?>
                                                        <?php echo e(Auth::user()->othername[0].'.'); ?>

                                                    <?php endif; ?>
                                                </div>
                                                <?php if(Auth::user()->role == 'member'): ?>
                                                    <?php if(!empty(Auth::user()->author)): ?>
                                                    <div class="small sub header"><?php echo e(ucfirst(Auth::user()->author)); ?></div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                <div class="small sub header"><?php echo e(ucfirst(Auth::user()->role)); ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="ui basic fluid horizontal segments border-0">
                                            <div class="ui center aligned secondary segment border-0 bg-transparent">
                                                <i class="big icons p-rel link">
                                                    <i class="mail icon"></i>
                                                    <div class="ui floating orange circular label">?</div>
                                                </i>
                                            </div>
                                            <div class="ui center aligned secondary segment border-0 bg-transparent">
                                                <i class="big icons p-rel link">
                                                    <i class="chat icon"></i>
                                                    <div class="ui floating orange circular label">?</div>
                                                </i>
                                            </div>
                                            <div class="ui center aligned secondary segment border-0 bg-transparent">
                                                <i class="big icons p-rel link">
                                                    <i class="edit icon"></i>
                                                    <div class="ui floating orange circular label">?</div>
                                                </i>
                                            </div>
                                        </div>
                                        
    
                                        <a href="<?php echo e(route('profiles.user', Auth::user()->username)); ?>" class="ui fluid basic orange button mt-10">My Profile</a>
                                        <?php if(!empty(Auth::user()->author)): ?>
                                            <?php if(Auth::user()->author == 'Editor'): ?>
                                            <a href="<?php echo e(route('articles.index')); ?>" class="ui fluid basic orange button mt-10">Manage Articles</a>
                                            <?php else: ?>
                                            <a href="<?php echo e(route('articles.create')); ?>" class="ui fluid basic orange button mt-10">Write An Article</a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <div class="ui fluid red button mt-10 logout_button">Logout</div>
                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                        </form>
                                                
                                    </div>
                                </div>
                            </div>
                            
                            <?php endif; ?>
                            <a href="https://web.facebook.com/IABCAfrica" class="ui icon item" data-tooltip="Like Us on Facebook" data-position="bottom center" data-variation="basic">
                                <i class="facebook f icon"></i>
                            </a>
                            <a href="https://twitter.com/IABC_Africa" class="ui icon item" data-tooltip="Follow Us on Twitter" data-position="bottom right" data-variation="basic">
                                <i class="twitter icon"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <!--  -->
            </div>
        </div>
    <!-- </div> -->
</div>


<?php $__env->startSection('custom_script'); ?>



    

<?php $__env->stopSection(); ?>








<?php /**PATH /home2/iabcafri/iabc/resources/views/partials/_nav.blade.php ENDPATH**/ ?>