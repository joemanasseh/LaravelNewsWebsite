<?php echo e($slot); ?>

<?php /**PATH /home2/iabcafri/iabc/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>