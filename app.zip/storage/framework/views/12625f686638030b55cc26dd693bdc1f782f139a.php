<?php $__env->startSection('title', 'IABC Africa - Manage Users'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="ui container">
        <div class="ui very padded stackable grid">
            <div class="ui sixteen wide column">
                <div class="ui huge centered header">Manage Users</div>
                <div class="ui divider"></div>
                <div class="ui segment">
                    <div class="ui very padded stackable grid">
                        <!--  -->
                        <div class="two column row">
                            <div class="ui twelve wide column">
                                <div class="ui large centered header">All Users</div>
                                <div class="ui dummy-x-scroll mb-0">
                                    <table class="ui celled unstackable table"></table>
                                </div>
                                <div class="ui table x-scroll mt-0">
                                    <table class="ui celled unstackable table">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Email</th>
                                                <th>Role</th>
                                                <th>Author</th>
                                                <th class="single line">
                                                    Created 
                                                    <i class="question circle icon"></i> 
                                                </th>
                                                <th>Status</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php if(count($users) == 0): ?>
                                        <tr>
                                            <td colspan="5">
                                                <div class="ui red centered header">No Users Found!</div>
                                            </td>
                                        </tr>
                                        <?php else: ?>
                                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php if(Auth::user()->role == 'superadmin'): ?>
                                                    <a href="<?php echo e(route('profiles.user', $user->username)); ?>">
                                                    <?php endif; ?>
                                                        <?php echo e($user->username); ?>

                                                    <?php if(Auth::user()->role == 'superadmin'): ?>
                                                    </a>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a class="mailto" href="">
                                                        <?php echo e($user->email); ?>

                                                    </a>
                                                </td>
                                                <td><?php echo e(ucfirst($user->role)); ?></td>
                                                <td><?php if(empty($user->author)): ?> <?php echo e(__('#N/A')); ?> <?php else: ?> <?php echo e($user->author); ?> <?php endif; ?></td>
                                                <td class="single line"><?php echo e(ucwords(timeago($user->created_at))); ?></td>
                                                <td> <div class="ui basic orange label">Active</div> </td>
                                                <td class="single line"> 
                                                    <button class="ui blue icon button edit_user_button" data-tooltip="Edit Profile" data-id="<?php echo e($user->id); ?>">
                                                        <i class="edit icon"></i>
                                                    </button>
                                                    <button class="ui grey icon button" data-tooltip="Disable User">
                                                        <i class="times icon"></i>
                                                    </button>

                                                    <!--  -->
                                                    <div class="ui tiny edit_user_modal <?php echo e($user->id); ?> modal" data-id="<?php echo e($user->role); ?>">
                                                        <i class="close icon"></i>
                                                        <div class="header">Edit User</div>
                                                        <div class="content">
                                                            <?php if(count($errors) > 0): ?>
                                                            <div class="ui error message">
                                                                <i class="ui close icon"></i>
                                                                <div class="header">Please check your input</div>
                                                                <ul class="list">
                                                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input_error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <li><?php echo e($input_error); ?></li>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </ul>
                                                            </div>
                                                            <?php endif; ?>
                                                            <form id="edit_user_form" class="ui form <?php echo e($user->id); ?>" method="POST" action="<?php echo e(route('users.update', $user->id)); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>

                                                                <div class="ui field <?php if($errors->has('user_name')): ?> error <?php endif; ?>">
                                                                    <label>Username</label>
                                                                    <input readonly id="user_name" type="text" name="user_name" placeholder="Name" value="<?php echo e($user->username); ?>" autocomplete="user_name" required>
                                                                </div>

                                                                <div class="ui field <?php if($errors->has('user_email')): ?> error <?php endif; ?>">
                                                                    <label>Email Address</label>
                                                                    <input readonly id="user_email" type="text" name="user_email" placeholder="Email" value="<?php echo e($user->email); ?>">
                                                                </div>

                                                                <div class="ui two fields">
                                                                    <div class="ui field <?php if($errors->has('role')): ?> error <?php endif; ?>">
                                                                        <label>Role</label>
                                                                        <div class="ui selection edit_user role_select <?php echo e($user->id); ?> fluid dropdown" data-selected="<?php echo e($user->role); ?>" data-id="<?php echo e($user->id); ?>">
                                                                            <input name="role" type="hidden">
                                                                            <i class="dropdown icon"></i>
                                                                            <div class="default text">User Role</div>
                                                                            <div class="menu" >
                                                                                <div class="item" data-value="superadmin"><?php echo e(__('Superadmin')); ?></div>
                                                                                <div class="item" data-value="admin"><?php echo e(__('Admin')); ?></div>
                                                                                <div class="item" data-value="member"><?php echo e(__('Member')); ?></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <div class="ui field <?php if($errors->has('author')): ?> error <?php endif; ?>">
                                                                        <label>Author</label>
                                                                        <div class="ui selection edit_user author_select <?php echo e($user->id); ?> fluid dropdown" data-selected="<?php echo e($user->author); ?>" data-id="<?php echo e($user->id); ?>">
                                                                            <input name="author" type="hidden">
                                                                            <i class="dropdown icon"></i>
                                                                            <div class="default text">Author Privileges</div>
                                                                            <div class="menu" >
                                                                                <div class="item" data-value="<?php echo e(__('')); ?>"><?php echo e(__('#N/A')); ?></div>
                                                                                <div class="item" data-value="<?php echo e(__('Editor')); ?>"><?php echo e(__('Editor')); ?></div>
                                                                                <div class="item" data-value="<?php echo e(__('Senior Contributor')); ?>"><?php echo e(__('Senior Contributor')); ?></div>
                                                                                <div class="item" data-value="<?php echo e(__('Contributor')); ?>"><?php echo e(__('Contributor')); ?></div>
                                                                                <div class="item" data-value="<?php echo e(__('VIP Contributor')); ?>"><?php echo e(__('VIP Contributor')); ?></div>
                                                                                <div class="item" data-value="<?php echo e(__('Guest Writer')); ?>"><?php echo e(__('Guest Writer')); ?></div>
                                                                                <div class="item" data-value="<?php echo e(__('Freelancer')); ?>"><?php echo e(__('Freelancer')); ?></div>
                                                                                <div class="item" data-value="<?php echo e(__('Writer')); ?>"><?php echo e(__('Writer')); ?></div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                

                                                            </form>
                                                        </div>
                                                        <div class="actions">
                                                            <div class="ui two column grid">
                                                                <div class="ui column">
                                                                    <div class="ui fluid approve orange button <?php echo e($user->id); ?>">Submit Changes</div>
                                                                </div>
                                                                <div class="ui column">
                                                                    <div class="ui fluid cancel red button">Cancel Edit</div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                                
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>

                                <!--  -->

                                
                                
                            </div>
                            <div class="four wide column">
                                <div class="ui large centered header">Create a User</div>
                                <?php if(count($errors) > 0): ?>
                                <div class="ui error message">
                                    <i class="ui close icon"></i>
                                    <div class="header">Please check your input</div>
                                    <ul class="list">
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $input_error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($input_error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                                <?php endif; ?>
                                <form id="register" class="ui form" method="POST" action="<?php echo e(route('register')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="field <?php if ($errors->has('lastname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('lastname'); ?> error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <label>Last Name</label>
                                        <input id="lastname" type="text" name="lastname" placeholder="Enter Last Name" value="<?php echo e(old('lastname')); ?>" autocomplete="lastname" required>
                                    </div>
                                    <div class="field <?php if ($errors->has('firstname')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('firstname'); ?> error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <label>First Name</label>
                                        <input id="firstname" type="text" name="firstname" placeholder="Enter First Name" value="<?php echo e(old('firstname')); ?>" autocomplete="firstname" required>
                                    </div>
                                    <div class="hidden eight wide computer sixteen wide mobile field <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <label>Username</label>
                                        <input id="username" type="text" name="username" placeholder="e.g. surname_firstname" value="<?php echo e(old('username')); ?>" autocomplete="username" required>
                                    </div>
                                    <div class="field <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <label>Email Address</label>
                                        <input id="email" type="email" name="email" placeholder="Enter valid email address" value="<?php echo e(old('email')); ?>" autocomplete="email" required>
                                    </div>
                                    <div class="field <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                        <label>Password</label>
                                        <input id="password" type="password" name="password" placeholder="Password" required>
                                    </div>
                                    <div class="field">
                                        <label>Confirm Password</label>
                                        <input id="password-confirm" type="password" name="password_confirmation" placeholder="Password" autocomplete="new-password" required>
                                    </div>

                                    <button class="ui orange large fluid button" type="submit">Create User</button>
                                </form>
                            </div>
                        </div>
                        <!--  -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    

<?php $__env->stopSection(); ?>


<?php $__env->startSection('custom_script'); ?>


$('.edit_user_button').click(function(e) {
    e.preventDefault();

    var user_id = $(this).attr('data-id');

    var role = $(this).siblings('.edit_user_modal').find('.role_select').attr('data-selected');
    $('.role_select.'+user_id).dropdown('set selected', role);

    var author = $(this).siblings('.edit_user_modal').find('.author_select').attr('data-selected');
    $('.author_select.'+user_id).dropdown('set selected', author);

    $('.edit_user_modal.'+user_id).modal({
        closable  : false,
        onApprove   : function(){
        $(this).find('.ui.approve.button').addClass('loading disabled').parent()
        .parent().find('.cancel').addClass('disabled');
        return false;
        }
    }).modal('show')
    .find('.ui.approve.button').click(function() {
        $('#edit_user_form.'+user_id).submit();
    });

    
});


$(function(){

    var table_width = $('.x-scroll>table.table').width();
    $('.dummy-x-scroll>table.table').css('width', table_width);

    $(".dummy-x-scroll").scroll(function(){
        $(".x-scroll")
            .scrollLeft($(".dummy-x-scroll").scrollLeft());
    });
    $(".x-scroll").scroll(function(){
        $(".dummy-x-scroll")
            .scrollLeft($(".x-scroll").scrollLeft());
    });
});



$('input#lastname').blur(function() {
    var lastname = $('input#lastname').val();
    var lastnames = lastname.replace(/\s+/g,' ').trim().split(' ');
    if(lastnames.length > 1) {
        lastnameCap =   (lastnames[0].charAt(0).toUpperCase() + lastnames[0].slice(1))
                        + '-' + 
                        (lastnames[1].charAt(0).toUpperCase() + lastnames[1].slice(1));
        $('input#lastname').val(lastnameCap);
    } else {
        lastnameCap = (lastnames[0].charAt(0).toUpperCase() + lastnames[0].slice(1));
        $('input#lastname').val(lastnameCap);
    }
});

$('input#firstname').blur(function() {
    var firstname = $('input#firstname').val();
    var firstnames = firstname.replace(/\s+/g,' ').trim().split(' ');
    if(firstnames.length > 1) {
        firstnameCap =   (firstnames[0].charAt(0).toUpperCase() + firstnames[0].slice(1));
        $('input#firstname').val(firstnameCap);
    } else {
        firstnameCap = (firstnames[0].charAt(0).toUpperCase() + firstnames[0].slice(1));
        $('input#firstname').val(firstnameCap);
    }
});

$('input#email').focus(function() {
    var lastname = $('input#lastname').val();
    var firstname = $('input#firstname').val();
    var time = (($.now()).toString(16)).slice(-5);
    $('input#username').val(lastname+'_'+firstname+'_'+time);
});


$('a.mailto').click(function(e) {
    e.preventDefault();
    $(this).attr('href', 'mailto:' + $.trim($(this).text()));
    $(this).removeClass('mailto').unbind('click').click();
});

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\IABC\iabc_africa\resources\views/manage_users.blade.php ENDPATH**/ ?>