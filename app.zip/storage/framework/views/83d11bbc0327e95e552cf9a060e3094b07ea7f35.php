

<?php $__env->startSection('content'); ?>

    <section class="ui container">
        
        <div class="ui grid">
            <div class="ui eight wide computer sixteen wide mobile centered column">
                <div class="ui raised segments">
                    <div class="ui center aligned raised segment">
                        <div class="ui huge header mb-0">IABC Africa</div>
                        <div class="ui text">Login into your account to gain access to member exclusive bonuses</div>
                    </div>
                    <div class="ui raised segment">
                        <div class="ui very padded stackable grid">
                            <div class="ui two column row">
                                <div class="ui column">
                                    <div class="ui labeled icon fluid blue button login px-0">
                                        <i class="facebook f icon"></i>
                                        <span>Login with Facebook</span>
                                    </div>
                                </div>
                                <div class="ui column">
                                    <div class="ui labeled icon fluid red button login">
                                        <i class="google icon"></i>
                                        <span>Login with Google</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--  -->
                        <div class="ui very padded grid">
                            <div class="ui column">
                                <form class="ui error form" method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php if(count($errors) > 0): ?>
                                    <div class="ui error message">
                                        <div class="header">Please check your input</div>
                                        <ul class="list">
                                            <li><?php echo e($errors->first('email')); ?></li>
                                        </ul>
                                    </div>
                                    <?php endif; ?>
                                    <div class="field">
                                        <label>Email</label>
                                        <input id="email" type="email" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>" autocomplete="email" required>
                                    </div>
                                    <div class="field <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> error <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?> ">
                                        <label>Password</label>
                                        <input id="password" type="password" name="password" placeholder="Password" required>
                                    </div>
                                    <div class="field">
                                        <div class="ui checkbox">
                                            <input type="checkbox" tabindex="0" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                            <label for="remember">Remember Me</label>
                                        </div>
                                        <a href="<?php echo e(route('password.request')); ?>" class="ui right floated primary tiny header">Forgot Password?</a>
                                    </div>
                                    <button class="ui orange large fluid button" type="submit">Login</button>
                                </form>
                                
                            </div>
                            
                        </div>
                        <!--  -->
                        <div class="ui very padded grid">
                            <div class="ui center aligned column">
                                <div class="ui text">Don't have an account? &nbsp; <a href="<?php echo e(route('register')); ?>" class="ui tiny primary header"> Sign Up</a> </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
        <!--  -->
        
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>

    $('form').submit(function() {
        $('.button[type="submit"]').addClass('loading');
    });
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iabcafri/iabc/resources/views/auth/login.blade.php ENDPATH**/ ?>