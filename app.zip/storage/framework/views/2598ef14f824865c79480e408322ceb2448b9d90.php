<h3>Contact Us Form - IABC Africa</h3>

<div>
    <dl>
        <dt>Subject: </dt>
        <dd><?php echo e($subject); ?></dd>

        <dt>Name: </dt>
        <dd><?php echo e($name); ?></dd>

        <dt>Email Address: </dt>
        <dd><?php echo e($email); ?></dd>

        <dt>Message: </dt>
        <dd><?php echo e($bodyMessage); ?></dd>
    </dl>
</div>

<p>Sent via Contact Us Form [<a href="https://iabcafrica.com">IABC Africa</a>]</p><?php /**PATH /home2/iabcafri/iabc/resources/views/emails/contact_us.blade.php ENDPATH**/ ?>