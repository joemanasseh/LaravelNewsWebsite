<?php $__env->startSection('title', 'IABC Africa - ' . $user->lastname.' '.$user->firstname); ?>


<?php $__env->startSection('content'); ?>
<div class="mt45"></div>

<section class="ui grid">
    <div class="ui light-grey row p-20">
        <div class="sixteen wide column">
            <div class="ui container">
                <div class="ui grid">
                    <div class="ui sixteen wide column">
                        <div class="ui items">
                            <div class="ui item">
                                <div class="ui medium circular image">
                                    <?php if(!empty($user->photo)): ?>
                                        <img src="<?php echo e(asset('img/users/'. $user->photo)); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('img/users/head.jpg')); ?>">
                                    <?php endif; ?>
                                </div>
                                <div class="middle aligned content">
                                    <div class="content_wrap">
                                        <div class="ui huge header">
                                            <?php echo e($user->lastname.' '.$user->firstname); ?>

                                            <?php if(!empty($user->othername)): ?>
                                                <?php echo e($user->othername); ?>

                                            <?php endif; ?>
                                        </div>
                                        <div class="description fs-1-5">
                                            <?php echo e(strtoupper($user->author)); ?>

                                        </div>
                                        <div class="meta fs-1-5 mt-15">
                                            <?php echo e($user->job_desc); ?>

                                        </div>
                                        <div class="mt-20">
                                        <?php if(count($user->socialmedias) != 0): ?>
                                            <?php $__currentLoopData = $user->socialmedias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialmedia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="https://<?php echo e($socialmedia->url); ?>"><i class="large circular <?php echo e($socialmedia->icon); ?> link icon"></i></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                             <a href="mailto:<?php echo e($user->email); ?>"><i class="large circular envelope link icon"></i></a>
                                        <?php else: ?>
                                            <a data-tooltip="No Social Media Registered"><i class="large circular question icon"></i></a>
                                        <?php endif; ?>
                                            <i class="icon"></i>
                                            <button class="ui orange button">Follow</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--  -->
                
            </div>
        </div>
    </div>
</section>

<section class="ui container">
    <div class="ui stackable grid mt-50">
        <div class="ui twelve wide column">
            <div class="ui huge header">About <?php echo e($user->lastname.' '.$user->firstname); ?></div>
            <div class="ui fluid raised card">
                <div class="content p-20">
                    <div class="description fs-1-5 text-justify mt10">
                        <?php if(!empty($user->about)): ?>
                        <p>
                            <?php echo $user->about; ?>

                        </p>
                        <?php else: ?>
                        <div class="ui tiny red centered header">No Description!</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!--  -->
            <div class="ui huge header mt-50">Books By <?php echo e($user->lastname.' '.$user->firstname); ?></div>
            <div class="ui fluid raised card">
                
                <div class="content p-20">
                    <div class="ui  unstackable  items">
                    <?php if(count($user->books) != 0): ?>
                        <?php $__currentLoopData = $user->books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item border border-orange rounded">
                            <a class="ui medium fluid image">
                                <img src="<?php echo e(asset('img/books/' . $book->cover)); ?>" class="ui fluid image">
                            </a>
                            <div class="content">
                                <br>
                                <div class="meta">
                                    <i class="ui yellow star icon mr-10"></i>
                                    F E A T U R E D
                                </div>
                                <div class="ui large header mt-10">
                                    <?php echo e($book->title); ?>

                                    <div class="sub header text-bold mt-10">
                                        By <?php echo e($user->lastname.' '.$user->firstname); ?>

                                    </div>
                                </div>
                                <div class="description fs-1-2 text-justify mt-15">
                                    <p><?php echo e($book->description); ?></p>
                                </div>
                                <br>
                                <div class="ui text">
                                    <strong>ISBN</strong>: <?php echo e($book->isbn); ?>

                                </div>
                                <div class="extra mt-20">
                                    <div class="ui orange button">Buy Now</div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="ui red centered header">No Books Found!</div>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
            <!--  -->
            <div class="ui huge header mt-50">Articles By <?php echo e($user->lastname.' '.$user->firstname); ?></div>
            <div class="ui fluid raised card">
                <div class="content p-20">
                    <div class="ui divided items">
                    <?php if(count($authorarticles) != 0): ?>
                        <?php $__currentLoopData = $authorarticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $authorarticle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="ui item author_article">
                            <div class="image">
                                <img src="<?php echo e(asset('img/articles/' . sprintf('%06d', $authorarticle->id) . '-' . slug($authorarticle->title) . '/featured/' . $authorarticle->image)); ?>">
                            </div>
                            <div class="content">
                                <a href="<?php echo e(route('articles.read', slug($authorarticle->title))); ?>" class="header d-block mt-5"><?php echo e($authorarticle->title); ?></a>
                                <div class="meta text-italic">
                                    <span><?php echo e($authorarticle->description); ?></span>
                                </div>
                                <div class="description article mt-5">
                                    <p>
                                        <?php echo str_limit($authorarticle->body, $limit = 200, $end = '...'); ?>

                                    </p>
                                </div>
                                <div class="ui divider"></div>
                                <div class="extra">
                                    <div class="ui horizontal relaxed article_meta list mt-5 text-black">
                                        <div class="item">
                                            <a href="<?php echo e(route('profiles.author', slug($authorarticle->user->username))); ?>">
                                                <div class="ui tiny text">
                                                    <i class="user icon"></i>
                                                    <?php echo e($authorarticle->user->lastname.' '.$authorarticle->user->firstname); ?>

                                                </div>
                                            </a>
                                        </div>
                                        <div class="item">
                                            <div class="ui tiny text">
                                                <i class="calendar alternate icon"></i>
                                                <?php echo e(date('jS F', strtotime($authorarticle->created_at))); ?>

                                            </div>
                                        </div>
                                        <div class="item">
                                            <div class="ui tiny text">
                                                <i class="book reader icon"></i>
                                                <?php echo e(round(str_word_count($authorarticle->body) / 250)); ?> mins
                                            </div>
                                        </div>
                                    </div>
                                    <!--  -->
                                    
                                </div>
                            </div>
                        </div>
                        <div class="ui article divider my-0"></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="ui red centered header">No Articles Found!</div>
                    <?php endif; ?>
                        <div class="ui grid">
                            <div class="six wide computer five wide mobile column pt-0 my-0"></div>
                            <div class="four wide computer six wide mobile column pt-0 mt-0">
                                <div class="ui fluid orange button show_all mt-10">Show All</div>
                            </div>
                            <div class="six wide computer five wide mobile column pt-0 my-0"></div>
                        </div>
                    </div>
                </div>
            </div>
            <!--  -->
            <div class="ui huge header mt-50">Videos By <?php echo e(ucfirst($user->lastname.' '.$user->firstname)); ?></div>
            <div class="ui fluid raised card">
                <div class="content p-20">
                    <div class="ui divided items">
                        <div class="ui red centered header">No Videos Found!</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="ui four wide column"></div>
    </div>
    <!--  -->
</section>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_script'); ?>

    $('.show_all').hide();
    
    var article_count = $('.author_article').length;
    if(article_count > 3) {
        $('.author_article').hide();
        $('.article.divider').hide();
        $('.author_article:lt(3)').show();
        $('.article.divider:lt(3)').show();
        $('.show_all').show();
    }

    $('button.show_all').click(function() {
        $('.author_article,.article.divider').show();
        $(this).hide();
    });

    $('.content_wrap').find('.link.icon').hover(
        function() {
            $(this).addClass('orange inverted')
        },
        function() {
            $(this).removeClass('orange inverted')
        }
    );

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_window_width_script'); ?>

    $('.content_wrap').addClass('text-center');

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_resize_if_script'); ?>

$('.content_wrap').removeClass('text-center');

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_resize_else_script'); ?>

    $('.content_wrap').addClass('text-center');

<?php $__env->stopSection(); ?>

<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/iabcafri/iabc/resources/views/profiles/author.blade.php ENDPATH**/ ?>