@extends('templates.master')

@section('content')

    <section>
        <div class="ui grid">
            <div class="sixteen wide computer only center aligned column">
                <div class="ui gigantic header">
                    COMING SOON
                </div>
                <div class="ui large header">
                    This Feature is Under Construction and Will be Available Soon
                </div>
                <img src="{{ asset('img/ui/loading.gif') }}" alt="">
            </div>
            <div class="fourteen wide centered mobile only center aligned column">
                <div class="ui bigger header">
                    COMING SOON
                </div>
                <div class="ui header">
                    This Feature is Under Construction and Will be Available Soon
                </div>
                <img src="{{ asset('img/ui/loading.gif') }}" alt="">
            </div>
        </div>
    </section>

@endsection

