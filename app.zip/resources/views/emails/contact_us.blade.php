<h3>Contact Us Form - IABC Africa</h3>

<div>
    <dl>
        <dt>Subject: </dt>
        <dd>{{ $subject }}</dd>

        <dt>Name: </dt>
        <dd>{{ $name }}</dd>

        <dt>Email Address: </dt>
        <dd>{{ $email }}</dd>

        <dt>Message: </dt>
        <dd>{{ $bodyMessage }}</dd>
    </dl>
</div>

<p>Sent via Contact Us Form [<a href="https://iabcafrica.com">IABC Africa</a>]</p>